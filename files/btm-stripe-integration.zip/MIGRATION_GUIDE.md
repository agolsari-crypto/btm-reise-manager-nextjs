# BTM Reise-Manager: Umstellung von PayPal auf Stripe Checkout
# ============================================================

## Übersicht der Änderungen

Diese Anleitung zeigt, welche Teile der btm-app.html geändert werden müssen,
um von der eigenen PayPal-Integration auf Stripe Checkout umzustellen.

---

## 1. PAYPAL CLIENT ID ENTFERNEN (Zeile ~220)

### ALT:
```javascript
const PAYPAL_CLIENT_ID = "ASTQW3cJaQ0n4NUuwFJk1hz84Di-_PLThRzpHHJKwPiYMvkqIokrq8nQ6rGNGV5k6ctI2Hxc2UaB5naF";
```

### NEU:
```javascript
// Stripe wird serverseitig konfiguriert - keine Client-ID nötig
const STRIPE_ENABLED = true;
```

---

## 2. PAYMENT MODAL KOMPLETT ERSETZEN (Zeile ~577-827)

Ersetze die gesamte PaymentModal-Komponente mit dieser neuen Version:

```javascript
// =====================================================
// STRIPE CHECKOUT MODAL KOMPONENTE
// =====================================================
const PaymentModal = ({ isOpen, onClose, product, price, onPaymentSuccess, patientName, doctorName, patientEmail }) => {
    const [isProcessing, setIsProcessing] = useState(false);
    const [error, setError] = useState(null);

    const handleStripeCheckout = async () => {
        setIsProcessing(true);
        setError(null);
        
        try {
            const response = await fetch('/api/stripe/create-checkout-session', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    amount: price,
                    patientName,
                    doctorName,
                    patientEmail
                })
            });
            
            const data = await response.json();
            
            if (!response.ok || !data.url) {
                throw new Error(data.error || 'Checkout konnte nicht gestartet werden');
            }
            
            // Formular-Daten im localStorage speichern für nach der Zahlung
            localStorage.setItem('nevpaz_pending_payment', JSON.stringify({
                formData: window.__btmFormData, // wird unten gesetzt
                timestamp: Date.now()
            }));
            
            // Zu Stripe Checkout weiterleiten
            window.location.href = data.url;
            
        } catch (err) {
            console.error('Stripe Checkout Error:', err);
            setError(err.message || 'Ein Fehler ist aufgetreten');
            setIsProcessing(false);
        }
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden animate-slide-up">
                {/* Header */}
                <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-6 text-white flex justify-between items-start">
                    <div>
                        <h3 className="text-xl font-bold flex items-center gap-3">
                            <Icons.Lock className="h-5 w-5 text-yellow-300" />
                            Sichere Zahlung
                        </h3>
                        <p className="text-indigo-100 text-sm mt-1">
                            via Stripe • Karte, PayPal, Apple Pay & mehr
                        </p>
                    </div>
                    <button 
                        onClick={onClose} 
                        disabled={isProcessing}
                        className="text-white/70 hover:text-white p-2 disabled:opacity-50"
                    >
                        <Icons.X className="h-6 w-6" />
                    </button>
                </div>

                {/* Content */}
                <div className="p-8">
                    {/* Produkt-Info */}
                    <div className="flex justify-between items-center mb-6 pb-6 border-b border-slate-100">
                        <div>
                            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Produkt</div>
                            <div className="text-lg font-bold text-slate-800">BTM-Formular & Attest</div>
                            {patientName && <div className="text-xs text-slate-500 mt-1">Patient: {patientName}</div>}
                        </div>
                        <div className="text-right">
                            <div className="text-[10px] text-slate-400 uppercase font-bold mb-1">Betrag</div>
                            <div className="text-3xl font-extrabold text-indigo-600">
                                {price.toFixed(2).replace('.', ',')} €
                            </div>
                        </div>
                    </div>

                    {/* Fehler */}
                    {error && (
                        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 flex items-center gap-3">
                            <Icons.AlertCircle className="h-5 w-5 flex-shrink-0" />
                            <span className="text-sm">{error}</span>
                            <button onClick={() => setError(null)} className="ml-auto">
                                <Icons.X className="h-4 w-4" />
                            </button>
                        </div>
                    )}

                    {/* Zahlungsmethoden-Info */}
                    <div className="mb-6 p-4 bg-slate-50 rounded-xl">
                        <div className="text-xs font-semibold text-slate-500 uppercase mb-3">Verfügbare Zahlungsarten</div>
                        <div className="flex flex-wrap gap-3 items-center">
                            {/* Kreditkarte */}
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-slate-200">
                                <Icons.CreditCard className="h-4 w-4 text-slate-600" />
                                <span className="text-xs font-medium text-slate-700">Karte</span>
                            </div>
                            {/* PayPal */}
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-slate-200">
                                <svg className="h-4 w-4 text-[#003087]" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M7.076 21.337H2.47a.641.641 0 0 1-.633-.74L4.944.901C5.026.382 5.474 0 5.998 0h7.46c2.57 0 4.578.543 5.69 1.81 1.01 1.15 1.304 2.42 1.012 4.287-.023.143-.047.288-.077.437-.983 5.05-4.349 6.797-8.647 6.797h-2.19c-.524 0-.968.382-1.05.9l-1.12 7.106z"/>
                                </svg>
                                <span className="text-xs font-medium text-slate-700">PayPal</span>
                            </div>
                            {/* Apple Pay */}
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-slate-200">
                                <svg className="h-4 w-4 text-slate-800" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.53 4.08zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/>
                                </svg>
                                <span className="text-xs font-medium text-slate-700">Apple Pay</span>
                            </div>
                            {/* Google Pay */}
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-lg border border-slate-200">
                                <svg className="h-4 w-4" viewBox="0 0 24 24">
                                    <path fill="#4285F4" d="M12.24 10.285V14.4h6.806c-.275 1.765-2.056 5.174-6.806 5.174-4.095 0-7.439-3.389-7.439-7.574s3.345-7.574 7.439-7.574c2.33 0 3.891.989 4.785 1.849l3.254-3.138C18.189 1.186 15.479 0 12.24 0c-6.635 0-12 5.365-12 12s5.365 12 12 12c6.926 0 11.52-4.869 11.52-11.726 0-.788-.085-1.39-.189-1.989H12.24z"/>
                                </svg>
                                <span className="text-xs font-medium text-slate-700">Google Pay</span>
                            </div>
                        </div>
                    </div>

                    {/* Checkout Button */}
                    <button
                        onClick={handleStripeCheckout}
                        disabled={isProcessing}
                        className="w-full py-4 px-6 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 disabled:from-slate-300 disabled:to-slate-400 text-white font-bold text-lg rounded-xl shadow-lg transition-all flex items-center justify-center gap-3"
                    >
                        {isProcessing ? (
                            <>
                                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                Weiterleitung...
                            </>
                        ) : (
                            <>
                                <Icons.CreditCard className="h-5 w-5" />
                                Jetzt sicher bezahlen
                            </>
                        )}
                    </button>

                    {/* Sicherheitshinweis */}
                    <div className="mt-6 pt-4 border-t border-slate-100">
                        <div className="flex items-center justify-center gap-2 text-[10px] text-slate-400">
                            <Icons.Shield className="h-3 w-3" />
                            <span>SSL-verschlüsselt • Stripe Secure • PCI-DSS zertifiziert</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};
```

---

## 3. PAYMENT SUCCESS HANDLING HINZUFÜGEN (in BtmTravelApp, nach den useEffect Hooks ~900)

Füge diesen neuen useEffect Hook hinzu, um nach erfolgreicher Zahlung zu reagieren:

```javascript
// Stripe Payment Success Handler
useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const paymentStatus = urlParams.get('payment');
    const sessionId = urlParams.get('session_id');
    
    if (paymentStatus === 'success' && sessionId) {
        // Verifiziere die Zahlung serverseitig
        const verifyPayment = async () => {
            try {
                const response = await fetch('/api/stripe/verify-session', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ sessionId })
                });
                
                const result = await response.json();
                
                if (result.verified) {
                    console.log('✅ Zahlung verifiziert:', result);
                    
                    // Gespeicherte Formulardaten laden
                    const pendingData = localStorage.getItem('nevpaz_pending_payment');
                    if (pendingData) {
                        const { formData: savedFormData } = JSON.parse(pendingData);
                        if (savedFormData) {
                            setFormData(savedFormData);
                        }
                        localStorage.removeItem('nevpaz_pending_payment');
                    }
                    
                    // PDF generieren
                    setTimeout(() => {
                        generatePDF('bundle');
                    }, 500);
                    
                    // URL bereinigen
                    window.history.replaceState({}, document.title, window.location.pathname);
                } else {
                    console.error('❌ Zahlung nicht verifiziert:', result.error);
                    alert('Die Zahlung konnte nicht verifiziert werden. Bitte kontaktieren Sie uns.');
                }
            } catch (err) {
                console.error('Verifizierungsfehler:', err);
            }
        };
        
        verifyPayment();
    } else if (paymentStatus === 'cancelled') {
        console.log('ℹ️ Zahlung abgebrochen');
        window.history.replaceState({}, document.title, window.location.pathname);
    }
}, []);
```

---

## 4. FORMULARDATEN VOR CHECKOUT SPEICHERN (in initiatePurchase ~968)

Vor dem Öffnen des Payment Modals die Formulardaten global verfügbar machen:

```javascript
const initiatePurchase = () => { 
    if (!formData.selectedDoctorId) {
        alert('Bitte wählen Sie zuerst einen Arzt aus.');
        return;
    }
    
    if (!isAdminMode && !currentUser) {
        setShowPatientLoginModal(true);
        return;
    }
    
    if (isAdminMode) {
        generatePDF('bundle');
        return;
    }
    
    // Formulardaten für nach der Zahlung speichern
    window.__btmFormData = { ...formData };
    
    setPendingProduct('bundle'); 
    setShowPaymentModal(true); 
};
```

---

## 5. SIDEBAR HINWEIS AKTUALISIEREN (Zeile ~2953-2961)

Ersetze den PayPal-Hinweis mit einem Stripe-Hinweis:

### ALT:
```jsx
{!isAdminMode && (
    <div className="mb-4 p-3 bg-[#ffc439]/10 border border-[#ffc439]/30 rounded-xl flex items-center gap-2">
        <svg className="h-5 w-5 text-[#003087]" viewBox="0 0 24 24" fill="currentColor">
            <path d="M7.076 21.337H2.47a..."/>
        </svg>
        <span className="text-xs text-[#003087] font-medium">Sichere Zahlung via PayPal</span>
    </div>
)}
```

### NEU:
```jsx
{!isAdminMode && (
    <div className="mb-4 p-3 bg-indigo-50 border border-indigo-200 rounded-xl flex items-center gap-2">
        <Icons.CreditCard className="h-5 w-5 text-indigo-600" />
        <span className="text-xs text-indigo-700 font-medium">Karte, PayPal, Apple Pay & mehr</span>
    </div>
)}
```

---

## 6. PAYMENT MODAL AUFRUF AKTUALISIEREN

Stelle sicher, dass beim Aufruf des PaymentModal auch die Email übergeben wird:

```jsx
{showPaymentModal && (
    <PaymentModal 
        isOpen={showPaymentModal} 
        onClose={() => setShowPaymentModal(false)} 
        product={pendingProduct}
        price={PRICES.bundle}
        onPaymentSuccess={handlePaymentSuccess}
        patientName={`${formData.patFirstName} ${formData.patName}`}
        doctorName={selectedDoctor?.name}
        patientEmail={currentUser?.email}
    />
)}
```

---

## Zusammenfassung der Dateien

### Neue Dateien zu erstellen:
1. `app/api/stripe/create-checkout-session/route.ts`
2. `app/api/stripe/verify-session/route.ts`

### Zu ändernde Dateien:
1. `public/btm-app.html` (siehe Änderungen oben)
2. `package.json` (Stripe hinzufügen)

### Environment Variables (`.env.local`):
```env
STRIPE_SECRET_KEY=sk_live_...
NEXT_PUBLIC_BASE_URL=https://reise.nevpaz.de
```

### Package.json Dependencies hinzufügen:
```bash
npm install stripe
```
